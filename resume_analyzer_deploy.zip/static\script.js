const fileInput = document.getElementById('resume-file');
const fileNameDisplay = document.getElementById('file-name');

fileInput.addEventListener('change', function (e) {
    if (e.target.files.length > 0) {
        fileNameDisplay.textContent = e.target.files[0].name;
        fileNameDisplay.style.color = 'var(--success-color)';
    } else {
        fileNameDisplay.textContent = "No file chosen";
        fileNameDisplay.style.color = '#aaa';
    }
});

document.getElementById('upload-form').addEventListener('submit', async function (e) {
    e.preventDefault();
    const fileInput = document.getElementById('resume-file');
    const file = fileInput.files[0];
    if (!file) {
        alert("Please select a file first.");
        return;
    }

    const formData = new FormData();
    formData.append('file', file);

    const loader = document.getElementById('loader');
    const resultsArea = document.getElementById('results-area');

    loader.style.display = 'block';
    resultsArea.style.display = 'none';

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });

        const data = await response.json();

        if (data.error) {
            alert(data.error);
            loader.style.display = 'none';
            return;
        }

        // Update Score
        updateScore(data.score);

        // Update Skills
        const skillsList = document.getElementById('skills-list');
        skillsList.innerHTML = '';
        data.skills.forEach(skill => {
            const li = document.createElement('li');
            li.textContent = skill;
            skillsList.appendChild(li);
        });

        // Update Jobs
        const jobsList = document.getElementById('jobs-list');
        jobsList.innerHTML = '';
        data.jobs.forEach(job => {
            const li = document.createElement('li');
            li.innerHTML = `
                <div>${job.role}</div>
                <div class="job-match-score">${job.match_score}% Match</div>
            `;
            jobsList.appendChild(li);
        });

        // Update Feedback
        const feedbackList = document.getElementById('feedback-list');
        feedbackList.innerHTML = '';
        data.feedback.forEach(fb => {
            const li = document.createElement('li');
            li.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${fb}`;
            feedbackList.appendChild(li);
        });

        loader.style.display = 'none';
        resultsArea.style.display = 'grid'; // Or block depending on layout

    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred during analysis.');
        loader.style.display = 'none';
    }
});

function updateScore(score) {
    const scoreCircle = document.getElementById('score-circle');
    const scoreText = document.querySelector('.score-text');
    scoreText.textContent = `${score}%`;

    // Update conic gradient
    scoreCircle.style.background = `conic-gradient(var(--success-color) ${score}%, transparent 0%)`;
}


// Chatbot Logic
const chatWindow = document.getElementById('chat-window');
const chatBody = document.getElementById('chat-body');
const chatInput = document.getElementById('chat-user-input');

function toggleChat() {
    chatWindow.style.display = chatWindow.style.display === 'flex' ? 'none' : 'flex';
}

function sendMessage() {
    const text = chatInput.value.trim();
    if (!text) return;

    // User Message
    addMessage(text, 'user-msg');
    chatInput.value = '';

    // Bot Response (Simple rules)
    setTimeout(() => {
        let botText = "I'm not sure about that. Try asking about 'resume length', 'skills', or 'projects'.";
        const lowerText = text.toLowerCase();

        if (lowerText.includes('resume') || lowerText.includes('cv')) {
            botText = "Keep your resume to 1-2 pages. Use bullet points and action verbs.";
        } else if (lowerText.includes('skill')) {
            botText = "Focus on relevant technical skills for the job you are applying for.";
        } else if (lowerText.includes('project')) {
            botText = "Include clear project descriptions with outcomes and technologies used.";
        } else if (lowerText.includes('hello') || lowerText.includes('hi')) {
            botText = "Hello! How can I help you improve your resume today?";
        }

        addMessage(botText, 'bot-msg');
    }, 500);
}

function addMessage(text, className) {
    const div = document.createElement('div');
    div.classList.add('message', className);
    div.textContent = text;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
}

// Allow Enter key to send message
chatInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

// Export Logic
document.getElementById('export-btn').addEventListener('click', async function () {
    // We need the data again. 
    // In a real app, store it in a variable. For now, we'll re-fetch or assume state.
    // Actually, let's just alert for now as re-fetching requires state management I skipped for brevity.
    // But to be helpful, let's just create a CSV from the DOM.

    // Simple client-side CSV export
    const skills = Array.from(document.querySelectorAll('#skills-list li')).map(li => li.textContent).join(';');
    const score = document.querySelector('.score-text').textContent;

    const csvContent = "data:text/csv;charset=utf-8,"
        + "Score,Skills\n"
        + `${score},"${skills}"`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "resume_analysis.csv");
    document.body.appendChild(link);
    link.click();
});
